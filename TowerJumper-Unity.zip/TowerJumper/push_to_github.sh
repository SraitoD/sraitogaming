#!/bin/bash
# ============================================================
# PUSH TO GITHUB — Tower Jumper
# ============================================================
# Exécute ce script depuis le dossier TowerJumper/
#
# Usage:
#   chmod +x push_to_github.sh
#   ./push_to_github.sh
# ============================================================

REPO_URL="https://github.com/sraitogaming/sraitogaming.git"

echo "🎮 Tower Jumper — Push to GitHub"
echo "================================"

# Init git if needed
if [ ! -d ".git" ]; then
    echo "📦 Initialisation du repo git..."
    git init
    git branch -M main
    git remote add origin "$REPO_URL"
else
    echo "✅ Repo git déjà initialisé"
fi

# Add all files
echo "📁 Ajout de tous les fichiers..."
git add -A

# Commit
echo "💾 Commit..."
git commit -m "🎮 Tower Jumper — projet Unity complet

- 15 scripts C# (physique manuelle, plateformes, biomes, UI, son)
- Gameplay Icy Tower: saut speed-based, wall bounce, combo, rush
- 4 personnages jouables
- 5 biomes (Ice Tower, Neon City, Lava Core, Void, Crystal)
- Mode Normal + Hardcore
- Seed reproductible + Ghost replay
- Contrôles mobiles (joystick + bouton saut)
- Leaderboard local Top 10
- Sons synthétisés (pas de fichiers audio)
- Script auto-setup de scène"

# Push
echo "🚀 Push vers GitHub..."
git push -u origin main --force

echo ""
echo "✅ Terminé ! Ton repo est à jour."
echo "🔗 https://github.com/sraitogaming/sraitogaming"
