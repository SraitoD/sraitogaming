using UnityEngine;
using System.Collections;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance { get; private set; }

    private AudioSource audioSource;
    private int sampleRate = 44100;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
    }

    // === WAVE GENERATORS ===
    float Square(float phase) => phase < 0.5f ? 1f : -1f;
    float Sine(float phase) => Mathf.Sin(phase * 2f * Mathf.PI);
    float Triangle(float phase) => 1f - 4f * Mathf.Abs(phase - 0.5f);
    float Sawtooth(float phase) => 2f * phase - 1f;

    AudioClip GenerateClip(string name, float duration, System.Func<float, float, float> generator)
    {
        int samples = Mathf.CeilToInt(sampleRate * duration);
        float[] data = new float[samples];
        for (int i = 0; i < samples; i++)
        {
            float t = (float)i / sampleRate;
            data[i] = generator(t, duration) * 0.3f; // master volume
        }
        AudioClip clip = AudioClip.Create(name, samples, 1, sampleRate, false);
        clip.SetData(data, 0);
        return clip;
    }

    void PlayClip(AudioClip clip)
    {
        audioSource.PlayOneShot(clip);
    }

    // === JUMP: Square wave 300→600Hz, 0.12s ===
    public void PlayJump()
    {
        var clip = GenerateClip("jump", 0.12f, (t, dur) =>
        {
            float freq = Mathf.Lerp(300, 600, t / dur);
            float phase = (t * freq) % 1f;
            float env = 1f - (t / dur);
            return Square(phase) * env;
        });
        PlayClip(clip);
    }

    // === LAND: Sine 200→80Hz, 0.08s ===
    public void PlayLand()
    {
        var clip = GenerateClip("land", 0.08f, (t, dur) =>
        {
            float freq = Mathf.Lerp(200, 80, t / dur);
            float phase = (t * freq) % 1f;
            float env = 1f - (t / dur);
            return Sine(phase) * env;
        });
        PlayClip(clip);
    }

    // === WALL BOUNCE: Triangle 400→800→500Hz, 0.15s ===
    public void PlayWallBounce()
    {
        var clip = GenerateClip("wallBounce", 0.15f, (t, dur) =>
        {
            float progress = t / dur;
            float freq;
            if (progress < 0.5f)
                freq = Mathf.Lerp(400, 800, progress * 2f);
            else
                freq = Mathf.Lerp(800, 500, (progress - 0.5f) * 2f);
            float phase = (t * freq) % 1f;
            float env = 1f - progress;
            return Triangle(phase) * env;
        });
        PlayClip(clip);
    }

    // === COMBO: Sine, pitch monte avec le combo ===
    public void PlayCombo(int comboCount)
    {
        float baseFreq = 500 + comboCount * 40;
        float endFreq = 800 + comboCount * 60;
        var clip = GenerateClip("combo", 0.18f, (t, dur) =>
        {
            float freq = Mathf.Lerp(baseFreq, endFreq, t / dur);
            float phase = (t * freq) % 1f;
            float env = 1f - (t / dur);
            return Sine(phase) * env;
        });
        PlayClip(clip);
    }

    // === RUSH: 3 sawtooth en arpège (400, 600, 800Hz), 0.08s entre chaque ===
    public void PlayRush()
    {
        StartCoroutine(RushArpeggio());
    }

    IEnumerator RushArpeggio()
    {
        float[] freqs = { 400, 600, 800 };
        foreach (float freq in freqs)
        {
            var clip = GenerateClip("rush_note", 0.1f, (t, dur) =>
            {
                float phase = (t * freq) % 1f;
                float env = 1f - (t / dur);
                return Sawtooth(phase) * env;
            });
            PlayClip(clip);
            yield return new WaitForSeconds(0.08f);
        }
    }

    // === TRICK: Sine 800→1200Hz, 0.15s ===
    public void PlayTrick()
    {
        var clip = GenerateClip("trick", 0.15f, (t, dur) =>
        {
            float freq = Mathf.Lerp(800, 1200, t / dur);
            float phase = (t * freq) % 1f;
            float env = 1f - (t / dur);
            return Sine(phase) * env;
        });
        PlayClip(clip);
    }

    // === MILESTONE: 4 sines C5-E5-G5-C6 ===
    public void PlayMilestone()
    {
        StartCoroutine(MilestoneArpeggio());
    }

    IEnumerator MilestoneArpeggio()
    {
        float[] freqs = { 523, 659, 784, 1047 };
        foreach (float freq in freqs)
        {
            var clip = GenerateClip("milestone_note", 0.15f, (t, dur) =>
            {
                float phase = (t * freq) % 1f;
                float env = 1f - (t / dur) * 0.5f;
                return Sine(phase) * env;
            });
            PlayClip(clip);
            yield return new WaitForSeconds(0.1f);
        }
    }

    // === GAME OVER: 4 square waves descendantes ===
    public void PlayGameOver()
    {
        StartCoroutine(GameOverSequence());
    }

    IEnumerator GameOverSequence()
    {
        float[] freqs = { 300, 250, 200, 150 };
        foreach (float freq in freqs)
        {
            var clip = GenerateClip("gameover_note", 0.2f, (t, dur) =>
            {
                float phase = (t * freq) % 1f;
                float env = 1f - (t / dur);
                return Square(phase) * env;
            });
            PlayClip(clip);
            yield return new WaitForSeconds(0.15f);
        }
    }
}
