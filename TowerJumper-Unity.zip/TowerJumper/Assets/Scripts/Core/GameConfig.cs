using UnityEngine;

[CreateAssetMenu(fileName = "GameConfig", menuName = "TowerJumper/GameConfig")]
public class GameConfig : ScriptableObject
{
    [Header("=== MODE SELECTION ===")]
    public GameMode mode = GameMode.Normal;

    // --- NORMAL MODE ---
    [Header("=== NORMAL MODE — Physics ===")]
    public float normalGravity = 1600f;
    public float normalJumpForceBase = 520f;
    public float normalJumpForceSpeedBonus = 350f;
    public float normalMoveAccel = 3200f;
    public float normalMaxSpeed = 440f;
    public float normalGroundFriction = 0.96f;
    public float normalAirFriction = 0.998f;

    [Header("=== NORMAL MODE — Wall Bounce ===")]
    public float normalWallBounceRetain = 0.93f;
    public float normalWallBounceVerticalKick = 280f;

    [Header("=== NORMAL MODE — Platforms ===")]
    public float normalPlatformMinW = 85f;
    public float normalPlatformMaxW = 150f;
    public float normalGapMin = 50f;
    public float normalGapMax = 70f;

    [Header("=== NORMAL MODE — Rising Floor ===")]
    public float normalFloorBaseSpeed = 2f;
    public float normalFloorAccel = 0.15f;
    public float normalFloorMaxSpeed = 120f;

    [Header("=== NORMAL MODE — Combo / Rush ===")]
    public float normalComboTimer = 0.6f;
    public float normalRushDuration = 5f;

    // --- HARDCORE MODE ---
    [Header("=== HARDCORE MODE — Physics ===")]
    public float hardcoreGravity = 1700f;
    public float hardcoreJumpForceBase = 500f;
    public float hardcoreJumpForceSpeedBonus = 400f;
    public float hardcoreMoveAccel = 3000f;
    public float hardcoreMaxSpeed = 480f;
    public float hardcoreGroundFriction = 0.90f;
    public float hardcoreAirFriction = 0.997f;

    [Header("=== HARDCORE MODE — Wall Bounce ===")]
    public float hardcoreWallBounceRetain = 0.90f;
    public float hardcoreWallBounceVerticalKick = 250f;

    [Header("=== HARDCORE MODE — Platforms ===")]
    public float hardcorePlatformMinW = 55f;
    public float hardcorePlatformMaxW = 100f;
    public float hardcoreGapMin = 60f;
    public float hardcoreGapMax = 85f;

    [Header("=== HARDCORE MODE — Rising Floor ===")]
    public float hardcoreFloorBaseSpeed = 4f;
    public float hardcoreFloorAccel = 0.25f;
    public float hardcoreFloorMaxSpeed = 160f;

    [Header("=== HARDCORE MODE — Combo / Rush ===")]
    public float hardcoreComboTimer = 0.4f;
    public float hardcoreRushDuration = 4f;

    // --- SHARED ---
    [Header("=== Rush ===")]
    public float rushFillPerCombo = 0.08f;
    public float rushSpeedMult = 1.35f;
    public float rushScoreMult = 2f;

    [Header("=== Difficulty Scaling ===")]
    public float diffScaleHeight = 10000f;
    public float diffGapBonus = 25f;
    public float diffWidthReduction = 17f;
    public float diffFragileChanceBonus = 0.1f;
    public float diffMobileChanceBonus = 0.08f;
    public float baseFragileChance = 0.08f;
    public float baseMobileChance = 0.05f;

    [Header("=== Milestone ===")]
    public int milestoneInterval = 50;

    [Header("=== Biomes ===")]
    public float biomeChangeHeight = 3000f;

    [Header("=== Tower Dimensions (pixels / units) ===")]
    public float towerWidth = 360f;
    public float wallThickness = 20f;

    [Header("=== Ghost ===")]
    public float ghostRecordInterval = 0.1f;

    // === ACCESSORS (retourne la valeur correcte selon le mode) ===
    public float Gravity => mode == GameMode.Normal ? normalGravity : hardcoreGravity;
    public float JumpForceBase => mode == GameMode.Normal ? normalJumpForceBase : hardcoreJumpForceBase;
    public float JumpForceSpeedBonus => mode == GameMode.Normal ? normalJumpForceSpeedBonus : hardcoreJumpForceSpeedBonus;
    public float MoveAccel => mode == GameMode.Normal ? normalMoveAccel : hardcoreMoveAccel;
    public float MaxSpeed => mode == GameMode.Normal ? normalMaxSpeed : hardcoreMaxSpeed;
    public float GroundFriction => mode == GameMode.Normal ? normalGroundFriction : hardcoreGroundFriction;
    public float AirFriction => mode == GameMode.Normal ? normalAirFriction : hardcoreAirFriction;
    public float WallBounceRetain => mode == GameMode.Normal ? normalWallBounceRetain : hardcoreWallBounceRetain;
    public float WallBounceVerticalKick => mode == GameMode.Normal ? normalWallBounceVerticalKick : hardcoreWallBounceVerticalKick;
    public float PlatformMinW => mode == GameMode.Normal ? normalPlatformMinW : hardcorePlatformMinW;
    public float PlatformMaxW => mode == GameMode.Normal ? normalPlatformMaxW : hardcorePlatformMaxW;
    public float GapMin => mode == GameMode.Normal ? normalGapMin : hardcoreGapMin;
    public float GapMax => mode == GameMode.Normal ? normalGapMax : hardcoreGapMax;
    public float FloorBaseSpeed => mode == GameMode.Normal ? normalFloorBaseSpeed : hardcoreFloorBaseSpeed;
    public float FloorAccel => mode == GameMode.Normal ? normalFloorAccel : hardcoreFloorAccel;
    public float FloorMaxSpeed => mode == GameMode.Normal ? normalFloorMaxSpeed : hardcoreFloorMaxSpeed;
    public float ComboTimer => mode == GameMode.Normal ? normalComboTimer : hardcoreComboTimer;
    public float RushDuration => mode == GameMode.Normal ? normalRushDuration : hardcoreRushDuration;
}

public enum GameMode
{
    Normal,
    Hardcore
}
