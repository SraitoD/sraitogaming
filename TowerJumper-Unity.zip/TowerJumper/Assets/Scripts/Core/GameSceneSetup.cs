using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Attach this to an empty GameObject in GameScene and click "Setup Scene" in the Inspector.
/// It will auto-create all required GameObjects and wire references.
/// Can also be called from menu: TowerJumper > Setup Game Scene
/// </summary>
public class GameSceneSetup : MonoBehaviour
{
#if UNITY_EDITOR
    [Header("Assign your GameConfig asset here")]
    public GameConfig config;

    [ContextMenu("Setup Game Scene")]
    public void SetupScene()
    {
        if (config == null)
        {
            Debug.LogError("Please assign a GameConfig ScriptableObject first!");
            return;
        }

        // ===== CAMERA =====
        Camera cam = Camera.main;
        if (cam == null)
        {
            var camGo = new GameObject("Main Camera");
            cam = camGo.AddComponent<Camera>();
            camGo.tag = "MainCamera";
        }
        cam.orthographic = true;
        cam.orthographicSize = 320; // fits 9:16 portrait
        cam.backgroundColor = new Color(0.1f, 0.16f, 0.3f);
        cam.transform.position = new Vector3(0, 200, -10);

        var cameraFollow = cam.GetComponent<CameraFollow>();
        if (cameraFollow == null) cameraFollow = cam.gameObject.AddComponent<CameraFollow>();
        cameraFollow.config = config;

        // ===== GAME MANAGER (if not present) =====
        if (GameManager.Instance == null)
        {
            var gmGo = new GameObject("GameManager");
            var gm = gmGo.AddComponent<GameManager>();
            gm.config = config;
        }

        // ===== SOUND MANAGER =====
        if (SoundManager.Instance == null)
        {
            var smGo = new GameObject("SoundManager");
            smGo.AddComponent<SoundManager>();
        }

        // ===== PLAYER =====
        var playerGo = GameObject.Find("Player");
        if (playerGo == null)
        {
            playerGo = new GameObject("Player");
            playerGo.transform.position = new Vector3(0, 30, 0);
        }

        var rb = playerGo.GetComponent<Rigidbody2D>();
        if (rb == null) rb = playerGo.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0;
        rb.freezeRotation = true;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

        var sr = playerGo.GetComponent<SpriteRenderer>();
        if (sr == null) sr = playerGo.AddComponent<SpriteRenderer>();
        sr.sortingOrder = 10;

        // Create player sprite
        Texture2D playerTex = new Texture2D(16, 24);
        Color[] pixels = new Color[16 * 24];
        for (int i = 0; i < pixels.Length; i++) pixels[i] = Color.white;
        playerTex.SetPixels(pixels);
        playerTex.Apply();
        playerTex.filterMode = FilterMode.Point;
        sr.sprite = Sprite.Create(playerTex, new Rect(0, 0, 16, 24), new Vector2(0.5f, 0.5f), 16);

        var pc = playerGo.GetComponent<PlayerController>();
        if (pc == null) pc = playerGo.AddComponent<PlayerController>();
        pc.config = config;
        pc.spriteRenderer = sr;

        var pa = playerGo.GetComponent<PlayerAnimator>();
        if (pa == null) pa = playerGo.AddComponent<PlayerAnimator>();
        pa.characters = new PlayerAnimator.CharacterData[]
        {
            new PlayerAnimator.CharacterData { name = "Harold", bodyColor = Color.white, headColor = Color.white, eyeColor = Color.black, accessoryColor = new Color(0.27f, 0.4f, 1f) },
            new PlayerAnimator.CharacterData { name = "Nina", bodyColor = new Color(1f, 0.47f, 0.67f), headColor = new Color(1f, 0.87f, 0.8f), eyeColor = new Color(0.2f, 0.1f, 0.05f), accessoryColor = new Color(1f, 0.13f, 0.4f) },
            new PlayerAnimator.CharacterData { name = "Blaze", bodyColor = new Color(1f, 0.4f, 0.2f), headColor = new Color(1f, 0.8f, 0.27f), eyeColor = Color.black, accessoryColor = new Color(1f, 0.13f, 0f) },
            new PlayerAnimator.CharacterData { name = "Pixel", bodyColor = new Color(0.27f, 1f, 0.67f), headColor = new Color(0.67f, 1f, 0.87f), eyeColor = new Color(0f, 0.4f, 0f), accessoryColor = new Color(0f, 0.8f, 0.4f) }
        };

        cameraFollow.player = pc;

        // ===== WORLD =====
        var worldGo = GameObject.Find("World");
        if (worldGo == null) worldGo = new GameObject("World");

        var poolMgr = worldGo.GetComponent<PoolManager>();
        if (poolMgr == null) poolMgr = worldGo.AddComponent<PoolManager>();

        var worldGen = worldGo.GetComponent<WorldGenerator>();
        if (worldGen == null) worldGen = worldGo.AddComponent<WorldGenerator>();
        worldGen.config = config;

        var biomeMgr = worldGo.GetComponent<BiomeManager>();
        if (biomeMgr == null) biomeMgr = worldGo.AddComponent<BiomeManager>();
        biomeMgr.mainCamera = cam;

        var wallRender = worldGo.GetComponent<WallRenderer>();
        if (wallRender == null) wallRender = worldGo.AddComponent<WallRenderer>();
        wallRender.config = config;

        var risingFloor = worldGo.GetComponent<RisingFloor>();
        if (risingFloor == null) risingFloor = worldGo.AddComponent<RisingFloor>();
        risingFloor.cameraFollow = cameraFollow;

        // ===== GHOST =====
        var ghostGo = GameObject.Find("GhostSystem");
        if (ghostGo == null) ghostGo = new GameObject("GhostSystem");
        var ghost = ghostGo.GetComponent<GhostRecorder>();
        if (ghost == null) ghost = ghostGo.AddComponent<GhostRecorder>();
        ghost.config = config;
        ghost.player = pc;

        // ===== CANVAS (HUD) =====
        var canvasGo = GameObject.Find("HUDCanvas");
        if (canvasGo == null)
        {
            canvasGo = new GameObject("HUDCanvas");
            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            canvasGo.AddComponent<UnityEngine.UI.CanvasScaler>().uiScaleMode =
                UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            canvasGo.GetComponent<UnityEngine.UI.CanvasScaler>().referenceResolution = new Vector2(1080, 1920);
            canvasGo.AddComponent<UnityEngine.UI.GraphicRaycaster>();
        }

        // Create HUD Controller
        var hud = canvasGo.GetComponent<HUDController>();
        if (hud == null) hud = canvasGo.AddComponent<HUDController>();
        hud.cameraFollow = cameraFollow;

        // Create HUD elements
        hud.scoreText = CreateUIText(canvasGo.transform, "ScoreText", new Vector2(30, -30), "0", 48, TextAnchor.UpperLeft);
        hud.bestText = CreateUIText(canvasGo.transform, "BestText", new Vector2(30, -80), "BEST: 0", 20, TextAnchor.UpperLeft);
        hud.comboText = CreateUIText(canvasGo.transform, "ComboText", new Vector2(-30, -30), "", 32, TextAnchor.UpperRight);
        hud.biomeText = CreateUIText(canvasGo.transform, "BiomeText", new Vector2(0, -10), "ICE TOWER", 16, TextAnchor.UpperCenter);
        hud.floorText = CreateUIText(canvasGo.transform, "FloorText", new Vector2(30, 120), "0\nFLOORS", 36, TextAnchor.LowerLeft);
        hud.dangerText = CreateUIText(canvasGo.transform, "DangerText", new Vector2(0, 200), "", 24, TextAnchor.LowerCenter);
        hud.trickText = CreateUIText(canvasGo.transform, "TrickText", new Vector2(0, 0), "FLIP!", 40, TextAnchor.MiddleCenter);

        // Combo container for scaling
        if (hud.comboText != null)
            hud.comboContainer = hud.comboText.rectTransform;

        // ===== GAME OVER UI =====
        var goUI = canvasGo.GetComponent<GameOverUI>();
        if (goUI == null) goUI = canvasGo.AddComponent<GameOverUI>();
        // Game over panel (hidden by default)
        var goPanel = CreateUIPanel(canvasGo.transform, "GameOverPanel");
        goUI.gameOverPanel = goPanel;
        goUI.gameOverTitle = CreateUIText(goPanel.transform, "GOTitle", new Vector2(0, 300), "GAME OVER", 56, TextAnchor.MiddleCenter);
        goUI.scoreText = CreateUIText(goPanel.transform, "GOScore", new Vector2(0, 200), "0 MÈTRES", 40, TextAnchor.MiddleCenter);
        goUI.floorText = CreateUIText(goPanel.transform, "GOFloors", new Vector2(0, 150), "0 FLOORS", 30, TextAnchor.MiddleCenter);
        goUI.newBestText = CreateUIText(goPanel.transform, "GONewBest", new Vector2(0, 100), "", 28, TextAnchor.MiddleCenter);
        goUI.bestScoreText = CreateUIText(goPanel.transform, "GOBest", new Vector2(0, 60), "BEST: 0", 24, TextAnchor.MiddleCenter);
        goUI.leaderboardText = CreateUIText(goPanel.transform, "GOLeaderboard", new Vector2(0, -50), "", 18, TextAnchor.UpperCenter);
        goUI.retryButton = CreateUIButton(goPanel.transform, "RetryButton", new Vector2(-120, -350), "RETRY");
        goUI.menuButton = CreateUIButton(goPanel.transform, "MenuButton", new Vector2(120, -350), "MENU");
        goPanel.SetActive(false);

        // ===== MOBILE CONTROLS =====
        var mobileCtrl = canvasGo.GetComponent<MobileControls>();
        if (mobileCtrl == null) mobileCtrl = canvasGo.AddComponent<MobileControls>();
        mobileCtrl.player = pc;

        Debug.Log("✅ Game Scene setup complete! All objects created and wired.");
    }

    UnityEngine.UI.Text CreateUIText(Transform parent, string name, Vector2 pos, string text, int fontSize, TextAnchor anchor)
    {
        var existing = parent.Find(name);
        if (existing != null) return existing.GetComponent<UnityEngine.UI.Text>();

        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(400, 100);

        // Set anchors based on alignment
        switch (anchor)
        {
            case TextAnchor.UpperLeft:
                rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
                break;
            case TextAnchor.UpperRight:
                rt.anchorMin = rt.anchorMax = new Vector2(1, 1);
                break;
            case TextAnchor.UpperCenter:
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 1);
                break;
            case TextAnchor.LowerLeft:
                rt.anchorMin = rt.anchorMax = new Vector2(0, 0);
                break;
            case TextAnchor.LowerCenter:
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0);
                break;
            default:
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                break;
        }

        var t = go.AddComponent<UnityEngine.UI.Text>();
        t.text = text;
        t.fontSize = fontSize;
        t.alignment = anchor;
        t.color = Color.white;
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        // Add outline
        var outline = go.AddComponent<UnityEngine.UI.Outline>();
        outline.effectColor = Color.black;
        outline.effectDistance = new Vector2(2, -2);

        return t;
    }

    UnityEngine.UI.Button CreateUIButton(Transform parent, string name, Vector2 pos, string label)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(200, 70);
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);

        var img = go.AddComponent<UnityEngine.UI.Image>();
        img.color = new Color(0.2f, 0.5f, 1f, 0.8f);

        var btn = go.AddComponent<UnityEngine.UI.Button>();
        btn.targetGraphic = img;

        // Label
        var labelGo = new GameObject("Label");
        labelGo.transform.SetParent(go.transform, false);
        var lrt = labelGo.AddComponent<RectTransform>();
        lrt.anchorMin = Vector2.zero;
        lrt.anchorMax = Vector2.one;
        lrt.sizeDelta = Vector2.zero;

        var t = labelGo.AddComponent<UnityEngine.UI.Text>();
        t.text = label;
        t.fontSize = 28;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = Color.white;
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        return btn;
    }

    GameObject CreateUIPanel(Transform parent, string name)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = Vector2.zero;

        var img = go.AddComponent<UnityEngine.UI.Image>();
        img.color = new Color(0, 0, 0, 0.85f);

        return go;
    }

    [MenuItem("TowerJumper/Setup Game Scene")]
    static void SetupFromMenu()
    {
        var setup = FindFirstObjectByType<GameSceneSetup>();
        if (setup != null)
            setup.SetupScene();
        else
            Debug.LogWarning("Add a GameSceneSetup component to a GameObject first and assign the GameConfig asset.");
    }
#endif
}
