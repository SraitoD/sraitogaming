using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Config")]
    public GameConfig config;

    // === STATE ===
    public enum GameState { Menu, Playing, GameOver }
    public GameState State { get; private set; } = GameState.Menu;

    // === SCORE ===
    public int Score { get; private set; }
    public int BestScore { get; private set; }
    public int FloorCount { get; private set; }
    public int HighestFloor { get; private set; }

    // === COMBO ===
    public int Combo { get; private set; }
    public float ComboTimeLeft { get; private set; }

    // === RUSH ===
    public float RushMeter { get; private set; }
    public bool RushActive { get; private set; }
    public float RushTimeLeft { get; private set; }

    // === SEED ===
    public int CurrentSeed { get; set; } = 0;
    public bool UseRandomSeed { get; set; } = true;
    public bool GhostEnabled { get; set; } = true;
    public int SelectedCharacter { get; set; } = 0;

    // === EVENTS ===
    public event Action OnScoreChanged;
    public event Action OnComboChanged;
    public event Action<bool> OnRushChanged;
    public event Action OnGameOver;
    public event Action<int> OnMilestone;
    public event Action<int> OnFloorChanged;
    public event Action<string> OnBiomeChanged;

    // === ELAPSED TIME ===
    public float ElapsedTime { get; private set; }

    // === PLAYER REF ===
    public float PlayerHeight { get; set; }

    private float effectiveMaxSpeed;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        BestScore = PlayerPrefs.GetInt($"BestScore_{config.mode}", 0);
    }

    public void StartGame()
    {
        if (UseRandomSeed)
            CurrentSeed = UnityEngine.Random.Range(1, 999999);

        State = GameState.Playing;
        Score = 0;
        FloorCount = 0;
        HighestFloor = 0;
        Combo = 0;
        ComboTimeLeft = 0;
        RushMeter = 0;
        RushActive = false;
        RushTimeLeft = 0;
        ElapsedTime = 0;
        PlayerHeight = 0;
        effectiveMaxSpeed = config.MaxSpeed;

        OnScoreChanged?.Invoke();
        OnComboChanged?.Invoke();
        OnRushChanged?.Invoke(false);

        SceneManager.LoadScene("GameScene");
    }

    void Update()
    {
        if (State != GameState.Playing) return;

        ElapsedTime += Time.deltaTime;

        // --- Combo timer ---
        if (Combo > 0)
        {
            ComboTimeLeft -= Time.deltaTime;
            if (ComboTimeLeft <= 0)
            {
                Combo = 0;
                OnComboChanged?.Invoke();
            }
        }

        // --- Rush timer ---
        if (RushActive)
        {
            RushTimeLeft -= Time.deltaTime;
            if (RushTimeLeft <= 0)
            {
                RushActive = false;
                OnRushChanged?.Invoke(false);
            }
        }

        // --- Score ---
        UpdateScore();
    }

    void UpdateScore()
    {
        float heightScore = Mathf.Floor(Mathf.Max(0, PlayerHeight - 100f) / 10f);
        float multiplier = RushActive ? config.rushScoreMult : 1f;
        int newScore = Mathf.FloorToInt(heightScore * multiplier);
        if (newScore > Score)
        {
            Score = newScore;
            OnScoreChanged?.Invoke();
        }
    }

    public void RegisterLanding(int floorNum, bool isMilestone)
    {
        if (State != GameState.Playing) return;

        // Floor count
        if (floorNum > HighestFloor)
        {
            HighestFloor = floorNum;
            FloorCount = floorNum;
            OnFloorChanged?.Invoke(FloorCount);
        }

        // Combo
        if (ComboTimeLeft > 0)
        {
            Combo++;
        }
        else
        {
            Combo = 1;
        }
        ComboTimeLeft = config.ComboTimer;
        OnComboChanged?.Invoke();

        // Rush fill
        if (!RushActive)
        {
            RushMeter += config.rushFillPerCombo;
            if (RushMeter >= 1f)
            {
                ActivateRush();
            }
        }

        // Milestone
        if (isMilestone)
        {
            OnMilestone?.Invoke(floorNum);
            SoundManager.Instance?.PlayMilestone();
        }
    }

    void ActivateRush()
    {
        RushActive = true;
        RushMeter = 0;
        RushTimeLeft = config.RushDuration;
        OnRushChanged?.Invoke(true);
        SoundManager.Instance?.PlayRush();
    }

    public float GetEffectiveMaxSpeed()
    {
        return RushActive ? config.MaxSpeed * config.rushSpeedMult : config.MaxSpeed;
    }

    public void TriggerGameOver()
    {
        if (State != GameState.Playing) return;
        State = GameState.GameOver;

        bool isNewBest = Score > BestScore;
        if (isNewBest)
        {
            BestScore = Score;
            PlayerPrefs.SetInt($"BestScore_{config.mode}", BestScore);
            PlayerPrefs.Save();
        }

        // Save leaderboard entry
        LeaderboardManager.SaveEntry(new LeaderboardEntry
        {
            score = Score,
            floors = FloorCount,
            characterIndex = SelectedCharacter,
            mode = config.mode.ToString(),
            seed = CurrentSeed,
            date = DateTime.Now.ToString("yyyy-MM-dd")
        });

        SoundManager.Instance?.PlayGameOver();
        OnGameOver?.Invoke();
    }

    public void ReturnToMenu()
    {
        State = GameState.Menu;
        SceneManager.LoadScene("MenuScene");
    }

    public void RetryGame()
    {
        StartGame();
    }

    public float GetDiffScale()
    {
        return Mathf.Clamp01(PlayerHeight / config.diffScaleHeight);
    }
}
