using UnityEngine;

public class MobilePlatform : PlatformBase
{
    private float origX;
    private float amplitude = 40f;
    private float speed = 1.5f;
    private float phase;

    public override void Initialize(float w, int floor, bool milestone, Color biomeColor)
    {
        base.Initialize(w, floor, milestone, biomeColor);
        spriteRenderer.color = mobileColor;
        origX = transform.position.x;
        phase = Random.Range(0f, Mathf.PI * 2f);
    }

    public void SetOscillation(float amp, float spd, float ph)
    {
        amplitude = amp;
        speed = spd;
        phase = ph;
        origX = transform.position.x;
    }

    void Update()
    {
        if (!gameObject.activeInHierarchy || IsBroken) return;

        float x = origX + Mathf.Sin(Time.time * speed + phase) * amplitude;
        transform.position = new Vector3(x, transform.position.y, transform.position.z);
    }
}
