using UnityEngine;

public class PlatformBase : MonoBehaviour
{
    [Header("Platform Properties")]
    public int FloorNum { get; set; }
    public bool IsMilestone { get; set; }
    public bool IsBroken { get; protected set; }

    protected SpriteRenderer spriteRenderer;
    protected float width;
    protected float height = 10f;

    // Colors
    protected static readonly Color normalColor = new Color(0.53f, 0.67f, 0.80f); // default ice
    protected static readonly Color fragileColor = new Color(1f, 0.42f, 0.42f); // #ff6b6b
    protected static readonly Color mobileColor = new Color(0.31f, 0.80f, 0.77f); // #4ecdc4
    protected static readonly Color milestoneColor = new Color(0.80f, 0.60f, 0f); // #cc9900

    public virtual void Initialize(float w, int floor, bool milestone, Color biomeColor)
    {
        width = w;
        FloorNum = floor;
        IsMilestone = milestone;
        IsBroken = false;

        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer == null)
            spriteRenderer = gameObject.AddComponent<SpriteRenderer>();

        // Create sprite if needed
        if (spriteRenderer.sprite == null)
            spriteRenderer.sprite = CreatePlatformSprite();

        // Scale to desired width
        transform.localScale = new Vector3(w / 16f, height / 16f, 1f);

        // Color
        if (milestone)
            spriteRenderer.color = milestoneColor;
        else
            spriteRenderer.color = biomeColor;

        spriteRenderer.sortingOrder = 5;
        gameObject.SetActive(true);
    }

    protected Sprite CreatePlatformSprite()
    {
        int texW = 16, texH = 16;
        Texture2D tex = new Texture2D(texW, texH);
        Color[] pixels = new Color[texW * texH];

        for (int y = 0; y < texH; y++)
        {
            for (int x = 0; x < texW; x++)
            {
                if (y == texH - 1 || y == texH - 2)
                    pixels[y * texW + x] = new Color(1, 1, 1, 0.4f); // top ice/snow highlight
                else if (y == 0)
                    pixels[y * texW + x] = new Color(0, 0, 0, 0.15f); // bottom shadow
                else if (x == 0 || x == texW - 1)
                    pixels[y * texW + x] = new Color(0, 0, 0, 0.08f); // side edges
                else
                    pixels[y * texW + x] = Color.white;
            }
        }

        tex.SetPixels(pixels);
        tex.Apply();
        tex.filterMode = FilterMode.Point;
        return Sprite.Create(tex, new Rect(0, 0, texW, texH), new Vector2(0.5f, 0.5f), 16);
    }

    public virtual void OnPlayerLand()
    {
        // Override in subclasses
    }

    public float GetTopY()
    {
        return transform.position.y + (height * transform.localScale.y) / (2f * (height / 16f));
    }

    public float GetLeftX()
    {
        return transform.position.x - width / 2f;
    }

    public float GetRightX()
    {
        return transform.position.x + width / 2f;
    }

    public void Deactivate()
    {
        gameObject.SetActive(false);
    }
}
