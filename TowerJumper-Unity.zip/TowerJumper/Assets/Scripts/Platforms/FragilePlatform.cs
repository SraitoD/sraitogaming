using UnityEngine;
using System.Collections;

public class FragilePlatform : PlatformBase
{
    private float breakDelay = 0.3f;
    private bool breaking = false;

    public override void Initialize(float w, int floor, bool milestone, Color biomeColor)
    {
        base.Initialize(w, floor, milestone, biomeColor);
        spriteRenderer.color = fragileColor;
        breaking = false;
        IsBroken = false;
        transform.localScale = new Vector3(w / 16f, height / 16f, 1f);
    }

    public override void OnPlayerLand()
    {
        if (!breaking)
        {
            breaking = true;
            StartCoroutine(BreakSequence());
        }
    }

    IEnumerator BreakSequence()
    {
        float timer = 0;
        Vector3 origScale = transform.localScale;

        // Shrink animation
        while (timer < breakDelay)
        {
            timer += Time.deltaTime;
            float t = timer / breakDelay;
            transform.localScale = origScale * (1f - t * 0.5f);

            // Flash red
            float flash = Mathf.Sin(t * Mathf.PI * 6f) * 0.3f;
            spriteRenderer.color = new Color(1f, 0.42f + flash, 0.42f + flash);

            yield return null;
        }

        IsBroken = true;
        // TODO: spawn break particles
        gameObject.SetActive(false);
    }
}
