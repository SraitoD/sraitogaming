using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    [Header("Character Data")]
    public CharacterData[] characters;

    private SpriteRenderer bodyRenderer;
    private SpriteRenderer headRenderer;
    private SpriteRenderer accessoryRenderer;
    private SpriteRenderer eyeRenderer;

    private PlayerController controller;
    private bool rushGlow;

    [System.Serializable]
    public class CharacterData
    {
        public string name;
        public Color bodyColor;
        public Color headColor;
        public Color eyeColor;
        public Color accessoryColor;
    }

    void Start()
    {
        controller = GetComponent<PlayerController>();

        // Create child sprite renderers for pixel art character
        bodyRenderer = CreateChildRenderer("Body", 0);
        headRenderer = CreateChildRenderer("Head", 1);
        eyeRenderer = CreateChildRenderer("Eyes", 2);
        accessoryRenderer = CreateChildRenderer("Accessory", 3);

        // Apply selected character
        int charIdx = GameManager.Instance != null ? GameManager.Instance.SelectedCharacter : 0;
        ApplyCharacter(charIdx);

        // Subscribe to rush events
        if (GameManager.Instance != null)
            GameManager.Instance.OnRushChanged += OnRushChanged;
    }

    void OnDestroy()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnRushChanged -= OnRushChanged;
    }

    SpriteRenderer CreateChildRenderer(string name, int sortOrder)
    {
        GameObject child = new GameObject(name);
        child.transform.SetParent(transform);
        child.transform.localPosition = Vector3.zero;
        var sr = child.AddComponent<SpriteRenderer>();
        sr.sortingOrder = sortOrder;
        // Create a simple white square sprite
        sr.sprite = CreateSquareSprite();
        return sr;
    }

    Sprite CreateSquareSprite()
    {
        Texture2D tex = new Texture2D(16, 16);
        Color[] pixels = new Color[16 * 16];
        for (int i = 0; i < pixels.Length; i++) pixels[i] = Color.white;
        tex.SetPixels(pixels);
        tex.Apply();
        tex.filterMode = FilterMode.Point;
        return Sprite.Create(tex, new Rect(0, 0, 16, 16), new Vector2(0.5f, 0.5f), 16);
    }

    public void ApplyCharacter(int index)
    {
        if (characters == null || index >= characters.Length) return;
        var c = characters[index];

        bodyRenderer.color = c.bodyColor;
        bodyRenderer.transform.localPosition = new Vector3(0, -4, 0);
        bodyRenderer.transform.localScale = new Vector3(0.8f, 1.2f, 1f);

        headRenderer.color = c.headColor;
        headRenderer.transform.localPosition = new Vector3(0, 6, 0);
        headRenderer.transform.localScale = new Vector3(0.9f, 0.9f, 1f);

        eyeRenderer.color = c.eyeColor;
        eyeRenderer.transform.localPosition = new Vector3(2, 7, 0);
        eyeRenderer.transform.localScale = new Vector3(0.2f, 0.25f, 1f);

        accessoryRenderer.color = c.accessoryColor;
        accessoryRenderer.transform.localPosition = new Vector3(0, 10, 0);
        accessoryRenderer.transform.localScale = new Vector3(0.7f, 0.3f, 1f);
    }

    void OnRushChanged(bool active)
    {
        rushGlow = active;
        if (active)
        {
            // Golden glow effect
            bodyRenderer.color = new Color(1f, 0.85f, 0.2f);
            headRenderer.color = new Color(1f, 0.9f, 0.3f);
        }
        else
        {
            int charIdx = GameManager.Instance != null ? GameManager.Instance.SelectedCharacter : 0;
            ApplyCharacter(charIdx);
        }
    }

    void Update()
    {
        if (rushGlow)
        {
            // Pulsing glow
            float pulse = 0.8f + 0.2f * Mathf.Sin(Time.time * 8f);
            bodyRenderer.color = new Color(1f, 0.85f * pulse, 0.2f * pulse);
        }
    }
}
