using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [Header("References")]
    public GameConfig config;
    public SpriteRenderer spriteRenderer;
    public Transform feetTransform; // child object at bottom of player

    // === STATE ===
    private Rigidbody2D rb;
    private float vx, vy;
    private bool grounded;
    private float prevFeetY;
    private int lastLandedFloor = -1;

    // === INPUT ===
    private float inputX;
    private bool jumpPressed;

    // === TRICKS ===
    private float totalRotation;
    private int completedFlips;
    private float currentRotation;

    // === TOWER BOUNDS ===
    private float leftWall;
    private float rightWall;
    private float playerHalfWidth = 8f;

    // === PLATFORM REF ===
    private PlatformBase currentPlatform;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0; // MANUAL GRAVITY
        rb.freezeRotation = true;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

        float towerW = config.towerWidth;
        float wallT = config.wallThickness;
        leftWall = -towerW / 2f + wallT + playerHalfWidth;
        rightWall = towerW / 2f - wallT - playerHalfWidth;

        prevFeetY = GetFeetY();
    }

    void Update()
    {
        // Read input (will be set by MobileControls or keyboard)
        ReadInput();
    }

    void FixedUpdate()
    {
        if (GameManager.Instance == null || GameManager.Instance.State != GameManager.GameState.Playing)
            return;

        float dt = Time.fixedDeltaTime;
        float effectiveMaxSpeed = GameManager.Instance.GetEffectiveMaxSpeed();

        // === GRAVITY ===
        vy -= config.Gravity * dt;

        // === HORIZONTAL MOVEMENT ===
        if (Mathf.Abs(inputX) > 0.15f)
        {
            vx += inputX * config.MoveAccel * dt;
            vx = Mathf.Clamp(vx, -effectiveMaxSpeed, effectiveMaxSpeed);

            // Friction with input
            if (grounded)
                vx *= Mathf.Pow(0.96f, dt * 60f);
        }
        else
        {
            // Friction without input
            float friction = grounded ? config.GroundFriction : config.AirFriction;
            vx *= Mathf.Pow(friction, dt * 60f);
        }

        // === JUMP ===
        if (jumpPressed && grounded)
        {
            float speedRatio = Mathf.Clamp01(Mathf.Abs(vx) / effectiveMaxSpeed);
            float jumpPower = config.JumpForceBase + config.JumpForceSpeedBonus * speedRatio;
            vy = jumpPower;
            grounded = false;
            currentPlatform = null;

            SoundManager.Instance?.PlayJump();
            SpawnJumpParticles();
        }

        // === APPLY VELOCITY ===
        float newX = rb.position.x + vx * dt;
        float newY = rb.position.y + vy * dt;

        // === WALL COLLISION ===
        if (newX <= leftWall)
        {
            newX = leftWall;
            if (!grounded) // Wall bounce in air
            {
                WallBounce(1f); // bounce right
            }
            else
            {
                vx = 0;
            }
        }
        else if (newX >= rightWall)
        {
            newX = rightWall;
            if (!grounded)
            {
                WallBounce(-1f); // bounce left
            }
            else
            {
                vx = 0;
            }
        }

        // === PLATFORM COLLISION (Sweep Test) ===
        float currFeetY = newY - GetFeetOffset();
        float prevFeet = prevFeetY;

        if (vy <= 0) // Only check when falling
        {
            PlatformBase hitPlatform = null;
            float highestPlatTop = float.NegativeInfinity;

            // Find all active platforms and check collision
            PlatformBase[] platforms = FindObjectsByType<PlatformBase>(FindObjectsSortMode.None);
            foreach (var plat in platforms)
            {
                if (!plat.gameObject.activeInHierarchy) continue;
                if (plat.IsBroken) continue;

                float platTop = plat.GetTopY();
                float platLeft = plat.GetLeftX();
                float platRight = plat.GetRightX();

                // Horizontal overlap?
                if (newX + playerHalfWidth < platLeft || newX - playerHalfWidth > platRight)
                    continue;

                // Sweep test: did feet cross platTop?
                if (prevFeet >= platTop - 2f && currFeetY <= platTop + 8f)
                {
                    if (platTop > highestPlatTop)
                    {
                        highestPlatTop = platTop;
                        hitPlatform = plat;
                    }
                }
            }

            if (hitPlatform != null)
            {
                Land(hitPlatform, highestPlatTop, ref newY);
            }
        }

        // === UPDATE POSITION ===
        rb.MovePosition(new Vector2(newX, newY));
        prevFeetY = newY - GetFeetOffset();

        // === UPDATE GAME MANAGER ===
        GameManager.Instance.PlayerHeight = newY;

        // === TRICKS ===
        UpdateTricks(dt);

        // === DEATH CHECK ===
        // (handled by RisingFloor / CameraFollow)

        jumpPressed = false;
    }

    void WallBounce(float direction)
    {
        float speed = Mathf.Abs(vx);
        vx = direction * speed * config.WallBounceRetain;

        float speedRatio = Mathf.Clamp01(speed / config.MaxSpeed);
        float vKick = config.WallBounceVerticalKick * (0.6f + 0.4f * speedRatio);
        vy = Mathf.Max(vy, vKick);

        SoundManager.Instance?.PlayWallBounce();
        SpawnWallBounceParticles(direction < 0 ? rb.position.x + playerHalfWidth : rb.position.x - playerHalfWidth);
    }

    void Land(PlatformBase platform, float platTop, ref float newY)
    {
        newY = platTop + GetFeetOffset();
        vy = 0;
        grounded = true;
        currentPlatform = platform;

        // Reset rotation
        if (completedFlips > 0)
        {
            completedFlips = 0;
        }
        totalRotation = 0;
        currentRotation = 0;
        transform.rotation = Quaternion.identity;

        // Register landing
        int floor = platform.FloorNum;
        if (floor != lastLandedFloor)
        {
            lastLandedFloor = floor;
            GameManager.Instance.RegisterLanding(floor, platform.IsMilestone);

            if (GameManager.Instance.Combo > 1)
                SoundManager.Instance?.PlayCombo(GameManager.Instance.Combo);
            else
                SoundManager.Instance?.PlayLand();
        }

        // Notify platform
        platform.OnPlayerLand();

        SpawnLandParticles();
    }

    void UpdateTricks(float dt)
    {
        if (grounded) return;

        float speedRatio = Mathf.Abs(vx) / config.MaxSpeed;
        if (speedRatio < 0.4f) return;

        float rotSpeed = speedRatio * 720f; // degrees per second
        float dir = vx > 0 ? -1f : 1f; // spin direction = movement direction
        float rotDelta = rotSpeed * dt * dir;

        totalRotation += Mathf.Abs(rotDelta);
        currentRotation += rotDelta;

        transform.rotation = Quaternion.Euler(0, 0, currentRotation);

        int newFlips = Mathf.FloorToInt(totalRotation / 360f);
        if (newFlips > completedFlips)
        {
            completedFlips = newFlips;
            SoundManager.Instance?.PlayTrick();
            // Spawn trick text via HUD
            string label = completedFlips == 1 ? "FLIP!" : completedFlips == 2 ? "DOUBLE!" : "TRIPLE!";
            HUDController.Instance?.ShowTrickText(label);
        }
    }

    // === INPUT INTERFACE ===
    void ReadInput()
    {
        // Keyboard fallback (PC/debug)
        float kbInput = 0;
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) kbInput -= 1;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) kbInput += 1;

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
            jumpPressed = true;

        // Mobile controls override (set externally)
        if (Mathf.Abs(mobileInputX) > 0.01f)
            inputX = mobileInputX;
        else
            inputX = kbInput;

        if (mobileJumpPressed)
        {
            jumpPressed = true;
            mobileJumpPressed = false;
        }
    }

    // === MOBILE INPUT (set by MobileControls) ===
    private float mobileInputX;
    private bool mobileJumpPressed;

    public void SetMobileInput(float x) { mobileInputX = x; }
    public void SetMobileJump() { mobileJumpPressed = true; }

    // === HELPERS ===
    float GetFeetY() => rb != null ? rb.position.y - GetFeetOffset() : transform.position.y - GetFeetOffset();
    float GetFeetOffset() => 12f; // half player height in pixels/units

    public bool IsGrounded => grounded;
    public float VelocityX => vx;
    public float VelocityY => vy;
    public Vector2 Velocity => new Vector2(vx, vy);

    // === CHECK IF BELOW DEATH ZONE ===
    public void CheckDeath(float deathY)
    {
        if (rb.position.y < deathY)
        {
            GameManager.Instance.TriggerGameOver();
        }
    }

    // === PARTICLES (placeholder — extend with ParticleSystem) ===
    void SpawnJumpParticles()
    {
        // TODO: Instantiate particle prefab at feet
    }

    void SpawnLandParticles()
    {
        // TODO: Instantiate particle prefab at feet
    }

    void SpawnWallBounceParticles(float xPos)
    {
        // TODO: Instantiate particle prefab at wall contact point
    }
}
