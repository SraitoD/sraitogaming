using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Config")]
    public GameConfig config;
    public PlayerController player;

    [Header("Camera Settings")]
    public float verticalOffset = 100f; // player appears in lower third
    public float smoothSpeed = 8f;

    // === RISING FLOOR ===
    public float FloorY { get; private set; }
    private float elapsedTime;
    private float currentRiseSpeed;

    // === DANGER LEVEL (0=safe, 1=rising, 2=faster, 3=danger) ===
    public int DangerLevel { get; private set; }

    private float highestY;
    private Camera cam;

    void Start()
    {
        cam = Camera.main;
        FloorY = cam.transform.position.y - cam.orthographicSize - 50f;
        highestY = transform.position.y;
    }

    void LateUpdate()
    {
        if (GameManager.Instance == null || GameManager.Instance.State != GameManager.GameState.Playing)
            return;

        float dt = Time.deltaTime;
        elapsedTime += dt;

        // === RISING FLOOR ===
        currentRiseSpeed = Mathf.Min(
            config.FloorBaseSpeed + elapsedTime * config.FloorAccel,
            config.FloorMaxSpeed
        );
        FloorY += currentRiseSpeed * dt;

        // Danger level
        if (currentRiseSpeed < 10f) DangerLevel = 0;
        else if (currentRiseSpeed < 40f) DangerLevel = 1;
        else if (currentRiseSpeed < 80f) DangerLevel = 2;
        else DangerLevel = 3;

        // === CAMERA POSITION ===
        if (player != null)
        {
            float targetY = Mathf.Max(player.transform.position.y + verticalOffset, FloorY + cam.orthographicSize + 20f);
            highestY = Mathf.Max(highestY, targetY);

            // Camera only moves UP (never down), except when rising floor forces it
            float camY = Mathf.Max(highestY, FloorY + cam.orthographicSize + 20f);
            float smoothY = Mathf.Lerp(transform.position.y, camY, smoothSpeed * dt);

            transform.position = new Vector3(0, smoothY, transform.position.z);

            // === DEATH CHECK ===
            float deathY = FloorY - 50f;
            player.CheckDeath(deathY);
        }
    }

    public float GetDeathZoneY()
    {
        return FloorY;
    }

    public float GetRiseSpeedNormalized()
    {
        return Mathf.Clamp01(currentRiseSpeed / config.FloorMaxSpeed);
    }
}
