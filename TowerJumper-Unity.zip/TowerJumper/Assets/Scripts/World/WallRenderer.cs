using UnityEngine;

public class WallRenderer : MonoBehaviour
{
    [Header("Config")]
    public GameConfig config;

    private SpriteRenderer leftWall;
    private SpriteRenderer rightWall;
    private Material wallMaterial;

    void Start()
    {
        float towerW = config.towerWidth;
        float wallT = config.wallThickness;

        // Left wall
        leftWall = CreateWall("LeftWall", new Vector3(-towerW / 2f + wallT / 2f, 0, 0), wallT);

        // Right wall
        rightWall = CreateWall("RightWall", new Vector3(towerW / 2f - wallT / 2f, 0, 0), wallT);
    }

    SpriteRenderer CreateWall(string name, Vector3 pos, float width)
    {
        var go = new GameObject(name);
        go.transform.SetParent(transform);
        go.transform.localPosition = pos;

        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = CreateBrickSprite();
        sr.drawMode = SpriteDrawMode.Tiled;
        sr.size = new Vector2(width, 2000f); // tall enough
        sr.sortingOrder = 2;

        Color brickColor = BiomeManager.Instance?.GetBrickColor() ?? new Color(0.23f, 0.33f, 0.47f);
        sr.color = brickColor;

        return sr;
    }

    Sprite CreateBrickSprite()
    {
        int texW = 32, texH = 16;
        Texture2D tex = new Texture2D(texW, texH);
        Color[] pixels = new Color[texW * texH];

        for (int y = 0; y < texH; y++)
        {
            for (int x = 0; x < texW; x++)
            {
                bool isMortar = false;

                // Horizontal mortar lines
                if (y == 0 || y == texH / 2)
                    isMortar = true;

                // Vertical mortar — offset on alternating rows
                int offset = (y < texH / 2) ? 0 : texW / 2;
                if ((x + offset) % texW == 0)
                    isMortar = true;

                if (isMortar)
                    pixels[y * texW + x] = new Color(0.1f, 0.1f, 0.1f, 0.5f);
                else
                {
                    // Brick with subtle highlight at top
                    float highlight = (y == texH - 1 || y == texH / 2 - 1) ? 0.15f : 0f;
                    pixels[y * texW + x] = new Color(1f, 1f, 1f, 0.6f + highlight);
                }
            }
        }

        tex.SetPixels(pixels);
        tex.Apply();
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Repeat;
        return Sprite.Create(tex, new Rect(0, 0, texW, texH), new Vector2(0.5f, 0.5f), 16, 0, SpriteMeshType.FullRect);
    }

    void LateUpdate()
    {
        // Keep walls centered on camera Y
        float camY = Camera.main.transform.position.y;
        if (leftWall != null)
            leftWall.transform.position = new Vector3(leftWall.transform.position.x, camY, 0);
        if (rightWall != null)
            rightWall.transform.position = new Vector3(rightWall.transform.position.x, camY, 0);

        // Update color with biome
        Color brickColor = BiomeManager.Instance?.GetBrickColor() ?? new Color(0.23f, 0.33f, 0.47f);
        if (leftWall != null) leftWall.color = brickColor;
        if (rightWall != null) rightWall.color = brickColor;
    }
}
