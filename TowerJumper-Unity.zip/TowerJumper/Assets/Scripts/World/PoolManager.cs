using UnityEngine;
using System.Collections.Generic;

public class PoolManager : MonoBehaviour
{
    public static PoolManager Instance { get; private set; }

    [Header("Prefabs")]
    public GameObject normalPlatformPrefab;
    public GameObject fragilePlatformPrefab;
    public GameObject mobilePlatformPrefab;

    private Dictionary<string, Queue<GameObject>> pools = new Dictionary<string, Queue<GameObject>>();
    private const int INITIAL_SIZE = 30;

    void Awake()
    {
        Instance = this;
    }

    public void InitializePools()
    {
        CreatePool("Normal", normalPlatformPrefab, INITIAL_SIZE);
        CreatePool("Fragile", fragilePlatformPrefab, INITIAL_SIZE / 3);
        CreatePool("Mobile", mobilePlatformPrefab, INITIAL_SIZE / 3);
    }

    void CreatePool(string key, GameObject prefab, int size)
    {
        if (prefab == null)
        {
            // Auto-create prefab
            prefab = CreatePlatformPrefab(key);
        }

        pools[key] = new Queue<GameObject>();
        for (int i = 0; i < size; i++)
        {
            var obj = Instantiate(prefab, transform);
            obj.SetActive(false);
            pools[key].Enqueue(obj);
        }
    }

    GameObject CreatePlatformPrefab(string type)
    {
        var go = new GameObject($"Platform_{type}");
        go.AddComponent<SpriteRenderer>();

        switch (type)
        {
            case "Fragile":
                go.AddComponent<FragilePlatform>();
                break;
            case "Mobile":
                go.AddComponent<MobilePlatform>();
                break;
            default:
                go.AddComponent<PlatformBase>();
                break;
        }

        return go;
    }

    public GameObject Get(string type)
    {
        if (!pools.ContainsKey(type))
            CreatePool(type, null, 10);

        if (pools[type].Count > 0)
        {
            var obj = pools[type].Dequeue();
            return obj;
        }
        else
        {
            // Expand pool
            var prefab = CreatePlatformPrefab(type);
            var obj = Instantiate(prefab, transform);
            return obj;
        }
    }

    public void Return(string type, GameObject obj)
    {
        obj.SetActive(false);
        if (pools.ContainsKey(type))
            pools[type].Enqueue(obj);
    }
}
