using UnityEngine;
using System.Collections.Generic;

public class WorldGenerator : MonoBehaviour
{
    [Header("Config")]
    public GameConfig config;

    private System.Random seededRandom;
    private float currentHeight = 0f;
    private int currentFloor = 0;
    private float lastGeneratedHeight = 0f;
    private float generationBuffer = 800f; // generate platforms this far ahead

    private float towerLeft;
    private float towerRight;
    private float usableWidth;

    // Track active platforms for cleanup
    private List<ActivePlatform> activePlatforms = new List<ActivePlatform>();

    struct ActivePlatform
    {
        public GameObject go;
        public string type;
        public float y;
    }

    void Start()
    {
        int seed = GameManager.Instance != null ? GameManager.Instance.CurrentSeed : 12345;
        seededRandom = new System.Random(seed);

        float towerW = config.towerWidth;
        float wallT = config.wallThickness;
        towerLeft = -towerW / 2f + wallT;
        towerRight = towerW / 2f - wallT;
        usableWidth = towerRight - towerLeft;

        // Initialize pool
        if (PoolManager.Instance != null)
            PoolManager.Instance.InitializePools();

        // Generate starting platform (full width, floor 0)
        SpawnStartPlatform();

        // Generate initial chunk
        GenerateUpTo(generationBuffer);
    }

    void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.State != GameManager.GameState.Playing)
            return;

        float cameraY = Camera.main.transform.position.y;
        float screenTop = cameraY + Camera.main.orthographicSize;

        // Generate ahead
        if (lastGeneratedHeight < screenTop + generationBuffer)
        {
            GenerateUpTo(screenTop + generationBuffer);
        }

        // Update biome
        if (BiomeManager.Instance != null)
            BiomeManager.Instance.UpdateBiome(GameManager.Instance.PlayerHeight);

        // Cleanup below camera
        CleanupBelow(cameraY - Camera.main.orthographicSize - 100f);
    }

    void SpawnStartPlatform()
    {
        var go = GetPlatform("Normal");
        var plat = go.GetComponent<PlatformBase>();
        plat.Initialize(usableWidth, 0, false, BiomeManager.Instance?.GetPlatformColor() ?? Color.white);
        go.transform.position = new Vector3(0, 0, 0);
        activePlatforms.Add(new ActivePlatform { go = go, type = "Normal", y = 0 });
        currentHeight = 0;
    }

    void GenerateUpTo(float targetHeight)
    {
        while (lastGeneratedHeight < targetHeight)
        {
            currentFloor++;

            // Difficulty scaling
            float diffScale = config.diffScaleHeight > 0 ?
                Mathf.Clamp01(lastGeneratedHeight / config.diffScaleHeight) : 0;

            // Gap between platforms
            float gapMin = config.GapMin + diffScale * config.diffGapBonus;
            float gapMax = config.GapMax + diffScale * config.diffGapBonus;
            float gap = Lerp(gapMin, gapMax, NextFloat());

            lastGeneratedHeight += gap;

            // Platform width
            float minW = config.PlatformMinW - diffScale * config.diffWidthReduction;
            float maxW = config.PlatformMaxW - diffScale * config.diffWidthReduction;
            minW = Mathf.Max(minW, 30f);
            maxW = Mathf.Max(maxW, minW + 10f);

            // Check milestone
            bool isMilestone = (currentFloor % config.milestoneInterval == 0);

            float platWidth;
            string platType;

            if (isMilestone)
            {
                // Milestone: full width, always normal
                platWidth = usableWidth;
                platType = "Normal";
            }
            else
            {
                platWidth = Lerp(minW, maxW, NextFloat());

                // Determine type
                float roll = NextFloat();
                float fragileChance = config.baseFragileChance + diffScale * config.diffFragileChanceBonus;
                float mobileChance = config.baseMobileChance + diffScale * config.diffMobileChanceBonus;

                if (roll < fragileChance)
                    platType = "Fragile";
                else if (roll < fragileChance + mobileChance)
                    platType = "Mobile";
                else
                    platType = "Normal";
            }

            // Position X
            float halfW = platWidth / 2f;
            float minX = towerLeft + halfW;
            float maxX = towerRight - halfW;
            float posX = Lerp(minX, maxX, NextFloat());

            // Spawn
            var go = GetPlatform(platType);
            var plat = go.GetComponent<PlatformBase>();
            Color biomeColor = BiomeManager.Instance?.GetPlatformColor() ?? Color.white;
            plat.Initialize(platWidth, currentFloor, isMilestone, biomeColor);
            go.transform.position = new Vector3(posX, lastGeneratedHeight, 0);

            // Mobile-specific setup
            if (platType == "Mobile" && go.TryGetComponent<MobilePlatform>(out var mobile))
            {
                float amp = Lerp(20f, 50f, NextFloat());
                float spd = Lerp(1f, 2.5f, NextFloat());
                float ph = NextFloat() * Mathf.PI * 2f;
                mobile.SetOscillation(amp, spd, ph);
            }

            // Add milestone label
            if (isMilestone)
            {
                AddMilestoneLabel(go, currentFloor);
            }

            activePlatforms.Add(new ActivePlatform { go = go, type = platType, y = lastGeneratedHeight });
        }
    }

    void AddMilestoneLabel(GameObject platGo, int floor)
    {
        // Create text label on milestone platform
        var labelGo = new GameObject("MilestoneLabel");
        labelGo.transform.SetParent(platGo.transform);
        labelGo.transform.localPosition = new Vector3(0, 4f, 0);

        var tm = labelGo.AddComponent<TextMesh>();
        tm.text = $"FLOOR {floor}";
        tm.fontSize = 24;
        tm.characterSize = 0.5f;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.alignment = TextAlignment.Center;
        tm.color = new Color(1f, 0.9f, 0.3f);
        tm.fontStyle = FontStyle.Bold;

        var mr = labelGo.GetComponent<MeshRenderer>();
        mr.sortingOrder = 10;
    }

    void CleanupBelow(float y)
    {
        for (int i = activePlatforms.Count - 1; i >= 0; i--)
        {
            if (activePlatforms[i].y < y)
            {
                ReturnPlatform(activePlatforms[i].type, activePlatforms[i].go);
                activePlatforms.RemoveAt(i);
            }
        }
    }

    GameObject GetPlatform(string type)
    {
        if (PoolManager.Instance != null)
            return PoolManager.Instance.Get(type);

        // Fallback: create new
        var go = new GameObject($"Platform_{type}");
        go.AddComponent<SpriteRenderer>();
        switch (type)
        {
            case "Fragile": go.AddComponent<FragilePlatform>(); break;
            case "Mobile": go.AddComponent<MobilePlatform>(); break;
            default: go.AddComponent<PlatformBase>(); break;
        }
        return go;
    }

    void ReturnPlatform(string type, GameObject go)
    {
        if (PoolManager.Instance != null)
            PoolManager.Instance.Return(type, go);
        else
            Destroy(go);
    }

    // === SEEDED RANDOM HELPERS ===
    float NextFloat()
    {
        return (float)seededRandom.NextDouble();
    }

    float Lerp(float a, float b, float t)
    {
        return a + (b - a) * t;
    }
}
