using UnityEngine;

public class BiomeManager : MonoBehaviour
{
    public static BiomeManager Instance { get; private set; }

    [System.Serializable]
    public class BiomeData
    {
        public string name;
        public Color bgTop;
        public Color bgBottom;
        public Color platformColor;
        public Color brickColor;
        public Color accentColor;
    }

    public BiomeData[] biomes;
    public Camera mainCamera;

    private int currentBiomeIndex = 0;
    private float biomeChangeHeight = 3000f;

    public BiomeData CurrentBiome => biomes != null && biomes.Length > 0 ? biomes[currentBiomeIndex] : null;
    public string CurrentBiomeName => CurrentBiome?.name ?? "ICE TOWER";

    void Awake()
    {
        Instance = this;
        if (biomes == null || biomes.Length == 0)
            InitializeDefaultBiomes();
    }

    void InitializeDefaultBiomes()
    {
        biomes = new BiomeData[]
        {
            new BiomeData {
                name = "ICE TOWER",
                bgTop = HexColor("#1a2a4e"),
                bgBottom = HexColor("#0c1a33"),
                platformColor = HexColor("#88aacc"),
                brickColor = HexColor("#3a5577"),
                accentColor = HexColor("#66ccff")
            },
            new BiomeData {
                name = "NEON CITY",
                bgTop = HexColor("#0d0221"),
                bgBottom = HexColor("#150734"),
                platformColor = HexColor("#ff006e"),
                brickColor = HexColor("#3a1570"),
                accentColor = HexColor("#00f5d4")
            },
            new BiomeData {
                name = "LAVA CORE",
                bgTop = HexColor("#1a0500"),
                bgBottom = HexColor("#0a0200"),
                platformColor = HexColor("#ff6633"),
                brickColor = HexColor("#4a2000"),
                accentColor = HexColor("#ffaa00")
            },
            new BiomeData {
                name = "VOID",
                bgTop = HexColor("#050008"),
                bgBottom = HexColor("#0a0012"),
                platformColor = HexColor("#9955ff"),
                brickColor = HexColor("#200a40"),
                accentColor = HexColor("#ff44aa")
            },
            new BiomeData {
                name = "CRYSTAL",
                bgTop = HexColor("#001510"),
                bgBottom = HexColor("#000a08"),
                platformColor = HexColor("#00ffa3"),
                brickColor = HexColor("#0a3828"),
                accentColor = HexColor("#00ccff")
            }
        };
    }

    public void UpdateBiome(float height)
    {
        if (biomes == null || biomes.Length == 0) return;

        int newIndex = Mathf.FloorToInt(height / biomeChangeHeight) % biomes.Length;
        if (newIndex != currentBiomeIndex)
        {
            currentBiomeIndex = newIndex;
            ApplyBiome();
            GameManager.Instance?.OnBiomeChanged?.Invoke(CurrentBiomeName);
        }
    }

    void ApplyBiome()
    {
        if (mainCamera != null)
        {
            mainCamera.backgroundColor = CurrentBiome.bgTop;
        }
    }

    public Color GetPlatformColor()
    {
        return CurrentBiome?.platformColor ?? Color.white;
    }

    public Color GetBrickColor()
    {
        return CurrentBiome?.brickColor ?? Color.gray;
    }

    static Color HexColor(string hex)
    {
        ColorUtility.TryParseHtmlString(hex, out Color c);
        return c;
    }
}
