using UnityEngine;

public class RisingFloor : MonoBehaviour
{
    [Header("References")]
    public CameraFollow cameraFollow;

    private SpriteRenderer dangerZone;
    private SpriteRenderer dangerLine;

    void Start()
    {
        // Create danger zone visual (red tint)
        var dzGo = new GameObject("DangerZone");
        dzGo.transform.SetParent(transform);
        dangerZone = dzGo.AddComponent<SpriteRenderer>();
        dangerZone.sprite = CreateSquareSprite();
        dangerZone.color = new Color(1f, 0f, 0f, 0.3f);
        dangerZone.sortingOrder = 20;

        // Create danger line (blinking)
        var dlGo = new GameObject("DangerLine");
        dlGo.transform.SetParent(transform);
        dangerLine = dlGo.AddComponent<SpriteRenderer>();
        dangerLine.sprite = CreateSquareSprite();
        dangerLine.color = new Color(1f, 0.2f, 0.2f, 0.8f);
        dangerLine.sortingOrder = 21;
    }

    void Update()
    {
        if (cameraFollow == null) return;

        float floorY = cameraFollow.FloorY;

        // Position danger zone (fills below floor line)
        dangerZone.transform.position = new Vector3(0, floorY - 200f, 0);
        dangerZone.transform.localScale = new Vector3(500f, 400f, 1f);

        // Position danger line (at floor level)
        dangerLine.transform.position = new Vector3(0, floorY, 0);
        dangerLine.transform.localScale = new Vector3(500f, 2f, 1f);

        // Blink the line
        float blink = Mathf.Sin(Time.time * 6f);
        dangerLine.color = new Color(1f, 0.2f, 0.2f, 0.4f + 0.4f * blink);

        // Intensity based on danger
        float riseNorm = cameraFollow.GetRiseSpeedNormalized();
        dangerZone.color = new Color(1f, 0f, 0f, 0.15f + riseNorm * 0.25f);
    }

    Sprite CreateSquareSprite()
    {
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1);
    }
}
