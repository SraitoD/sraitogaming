using UnityEngine;
using System.Collections.Generic;

public class GhostRecorder : MonoBehaviour
{
    [Header("Config")]
    public GameConfig config;
    public PlayerController player;

    [Header("Ghost Visual")]
    public Color ghostColor = new Color(1f, 1f, 1f, 0.25f);

    private List<GhostFrame> recordedFrames = new List<GhostFrame>();
    private List<GhostFrame> playbackFrames;
    private float recordTimer;
    private float playbackTimer;
    private int playbackIndex;

    private GameObject ghostObject;
    private SpriteRenderer ghostRenderer;
    private bool isRecording;
    private bool isPlaying;

    [System.Serializable]
    struct GhostFrame
    {
        public float x, y, rotation;
    }

    void Start()
    {
        if (GameManager.Instance == null || !GameManager.Instance.GhostEnabled) return;

        // Load previous ghost
        string key = GetGhostKey();
        string data = PlayerPrefs.GetString(key, "");
        if (!string.IsNullOrEmpty(data))
        {
            LoadGhost(data);
            CreateGhostVisual();
            isPlaying = true;
        }

        isRecording = true;
    }

    void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.State != GameManager.GameState.Playing)
            return;

        // Record
        if (isRecording && player != null)
        {
            recordTimer += Time.deltaTime;
            if (recordTimer >= config.ghostRecordInterval)
            {
                recordTimer -= config.ghostRecordInterval;
                recordedFrames.Add(new GhostFrame
                {
                    x = player.transform.position.x,
                    y = player.transform.position.y,
                    rotation = player.transform.eulerAngles.z
                });
            }
        }

        // Playback
        if (isPlaying && playbackFrames != null && ghostObject != null)
        {
            playbackTimer += Time.deltaTime;
            int frameIdx = Mathf.FloorToInt(playbackTimer / config.ghostRecordInterval);

            if (frameIdx < playbackFrames.Count)
            {
                var frame = playbackFrames[frameIdx];
                ghostObject.transform.position = new Vector3(frame.x, frame.y, 0);
                ghostObject.transform.rotation = Quaternion.Euler(0, 0, frame.rotation);
            }
            else
            {
                ghostObject.SetActive(false);
                isPlaying = false;
            }
        }
    }

    void OnDestroy()
    {
        // Save recording
        if (isRecording && recordedFrames.Count > 0)
        {
            SaveGhost();
        }
    }

    void CreateGhostVisual()
    {
        ghostObject = new GameObject("Ghost");
        ghostRenderer = ghostObject.AddComponent<SpriteRenderer>();

        Texture2D tex = new Texture2D(16, 24);
        Color[] pixels = new Color[16 * 24];
        for (int i = 0; i < pixels.Length; i++) pixels[i] = Color.white;
        tex.SetPixels(pixels);
        tex.Apply();
        tex.filterMode = FilterMode.Point;

        ghostRenderer.sprite = Sprite.Create(tex, new Rect(0, 0, 16, 24), new Vector2(0.5f, 0.5f), 16);
        ghostRenderer.color = ghostColor;
        ghostRenderer.sortingOrder = -1;
    }

    string GetGhostKey()
    {
        int seed = GameManager.Instance?.CurrentSeed ?? 0;
        string mode = GameManager.Instance?.config?.mode.ToString() ?? "Normal";
        return $"Ghost_{mode}_{seed}";
    }

    void SaveGhost()
    {
        // Simple serialization: x,y,r|x,y,r|...
        var sb = new System.Text.StringBuilder();
        foreach (var frame in recordedFrames)
        {
            sb.Append($"{frame.x:F1},{frame.y:F1},{frame.rotation:F0}|");
        }
        PlayerPrefs.SetString(GetGhostKey(), sb.ToString());
        PlayerPrefs.Save();
    }

    void LoadGhost(string data)
    {
        playbackFrames = new List<GhostFrame>();
        string[] parts = data.Split('|');
        foreach (string part in parts)
        {
            if (string.IsNullOrEmpty(part)) continue;
            string[] vals = part.Split(',');
            if (vals.Length >= 3)
            {
                playbackFrames.Add(new GhostFrame
                {
                    x = float.Parse(vals[0]),
                    y = float.Parse(vals[1]),
                    rotation = float.Parse(vals[2])
                });
            }
        }
    }
}
