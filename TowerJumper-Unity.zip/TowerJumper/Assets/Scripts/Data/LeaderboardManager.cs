using UnityEngine;
using System.Collections.Generic;
using System.Linq;

[System.Serializable]
public class LeaderboardEntry
{
    public int score;
    public int floors;
    public int characterIndex;
    public string mode;
    public int seed;
    public string date;
}

[System.Serializable]
public class LeaderboardData
{
    public List<LeaderboardEntry> entries = new List<LeaderboardEntry>();
}

public static class LeaderboardManager
{
    private const string KEY = "Leaderboard_v1";
    private const int MAX_ENTRIES = 10;

    public static void SaveEntry(LeaderboardEntry entry)
    {
        var data = Load();
        data.entries.Add(entry);
        data.entries = data.entries.OrderByDescending(e => e.score).Take(MAX_ENTRIES).ToList();
        Save(data);
    }

    public static List<LeaderboardEntry> GetTopEntries(int count = 10)
    {
        var data = Load();
        return data.entries.Take(Mathf.Min(count, data.entries.Count)).ToList();
    }

    private static LeaderboardData Load()
    {
        string json = PlayerPrefs.GetString(KEY, "");
        if (string.IsNullOrEmpty(json))
            return new LeaderboardData();
        return JsonUtility.FromJson<LeaderboardData>(json) ?? new LeaderboardData();
    }

    private static void Save(LeaderboardData data)
    {
        string json = JsonUtility.ToJson(data);
        PlayerPrefs.SetString(KEY, json);
        PlayerPrefs.Save();
    }

    public static void ClearAll()
    {
        PlayerPrefs.DeleteKey(KEY);
        PlayerPrefs.Save();
    }
}
