using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    [Header("UI Elements")]
    public Text titleText;
    public Button playButton;
    public Button modeToggleButton;
    public Text modeText;
    public InputField seedInput;
    public Button randomSeedButton;
    public Toggle ghostToggle;
    public Text bestScoreText;

    [Header("Character Selection")]
    public Button[] characterButtons;
    public Image[] characterPreviews;
    public Image selectionHighlight;

    [Header("Config")]
    public GameConfig config;

    private int selectedCharacter = 0;
    private bool isHardcore = false;

    private Color[] characterColors = new Color[]
    {
        Color.white,                            // Harold
        new Color(1f, 0.47f, 0.67f),           // Nina
        new Color(1f, 0.4f, 0.2f),             // Blaze
        new Color(0.27f, 1f, 0.67f)            // Pixel
    };

    void Start()
    {
        // Initialize
        if (GameManager.Instance != null)
        {
            isHardcore = config.mode == GameMode.Hardcore;
            selectedCharacter = GameManager.Instance.SelectedCharacter;
        }

        UpdateModeDisplay();
        UpdateBestScore();
        HighlightCharacter(selectedCharacter);

        // Button listeners
        if (playButton != null)
            playButton.onClick.AddListener(OnPlay);
        if (modeToggleButton != null)
            modeToggleButton.onClick.AddListener(OnToggleMode);
        if (randomSeedButton != null)
            randomSeedButton.onClick.AddListener(OnRandomSeed);
        if (ghostToggle != null)
            ghostToggle.isOn = GameManager.Instance?.GhostEnabled ?? true;

        // Character buttons
        for (int i = 0; i < characterButtons.Length; i++)
        {
            int idx = i;
            if (characterButtons[i] != null)
                characterButtons[i].onClick.AddListener(() => SelectCharacter(idx));
            if (characterPreviews != null && i < characterPreviews.Length && characterPreviews[i] != null)
                characterPreviews[i].color = characterColors[i];
        }

        // Title
        if (titleText != null)
            titleText.text = "TOWER\nJUMPER";

        OnRandomSeed(); // Start with random seed
    }

    void OnPlay()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;

        // Set seed
        if (seedInput != null && int.TryParse(seedInput.text, out int seed))
        {
            gm.CurrentSeed = seed;
            gm.UseRandomSeed = false;
        }
        else
        {
            gm.UseRandomSeed = true;
        }

        // Set mode
        config.mode = isHardcore ? GameMode.Hardcore : GameMode.Normal;

        // Set ghost
        gm.GhostEnabled = ghostToggle != null ? ghostToggle.isOn : true;

        // Set character
        gm.SelectedCharacter = selectedCharacter;

        gm.StartGame();
    }

    void OnToggleMode()
    {
        isHardcore = !isHardcore;
        UpdateModeDisplay();
        UpdateBestScore();
    }

    void OnRandomSeed()
    {
        int seed = Random.Range(1, 999999);
        if (seedInput != null)
            seedInput.text = seed.ToString();
    }

    void SelectCharacter(int index)
    {
        selectedCharacter = index;
        HighlightCharacter(index);
    }

    void HighlightCharacter(int index)
    {
        if (selectionHighlight != null && characterButtons != null && index < characterButtons.Length)
        {
            selectionHighlight.rectTransform.position = characterButtons[index].transform.position;
        }
    }

    void UpdateModeDisplay()
    {
        if (modeText != null)
        {
            modeText.text = isHardcore ? "HARDCORE" : "NORMAL";
            modeText.color = isHardcore ? new Color(1f, 0.3f, 0.3f) : new Color(0.3f, 1f, 0.5f);
        }
    }

    void UpdateBestScore()
    {
        if (bestScoreText != null)
        {
            string key = isHardcore ? "Hardcore" : "Normal";
            int best = PlayerPrefs.GetInt($"BestScore_{key}", 0);
            bestScoreText.text = $"BEST: {best}";
        }
    }
}
