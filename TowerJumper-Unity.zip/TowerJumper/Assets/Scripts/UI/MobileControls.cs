using UnityEngine;
using UnityEngine.EventSystems;

public class MobileControls : MonoBehaviour
{
    [Header("References")]
    public PlayerController player;

    [Header("Joystick Settings")]
    public RectTransform joystickArea;
    public RectTransform joystickBase;
    public RectTransform joystickThumb;
    public float joystickRadius = 50f;
    public float deadzone = 0.15f;

    [Header("Jump Button")]
    public RectTransform jumpButton;
    public UnityEngine.UI.Image jumpButtonImage;

    private int joystickTouchId = -1;
    private int jumpTouchId = -1;
    private Vector2 joystickCenter;
    private float inputX;

    private Color jumpNormalColor = new Color(1f, 1f, 1f, 0.5f);
    private Color jumpPressedColor = new Color(0.8f, 0.9f, 1f, 0.7f);

    void Update()
    {
        if (player == null) return;

        ProcessTouches();

        // Keyboard fallback already in PlayerController
        player.SetMobileInput(inputX);
    }

    void ProcessTouches()
    {
        // Reset if touches ended
        bool joystickActive = false;
        bool jumpActive = false;

        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch touch = Input.GetTouch(i);
            Vector2 pos = touch.position;

            // Determine which control this touch belongs to
            bool isLeftHalf = pos.x < Screen.width * 0.5f;

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    if (isLeftHalf && joystickTouchId == -1)
                    {
                        joystickTouchId = touch.fingerId;
                        joystickCenter = pos;
                        if (joystickBase != null)
                        {
                            joystickBase.position = pos;
                            joystickBase.gameObject.SetActive(true);
                        }
                    }
                    else if (!isLeftHalf && jumpTouchId == -1)
                    {
                        jumpTouchId = touch.fingerId;
                        player.SetMobileJump();
                        if (jumpButtonImage != null)
                        {
                            jumpButtonImage.color = jumpPressedColor;
                            jumpButton.localScale = Vector3.one * 0.92f;
                        }
                    }
                    break;

                case TouchPhase.Moved:
                case TouchPhase.Stationary:
                    if (touch.fingerId == joystickTouchId)
                    {
                        joystickActive = true;
                        Vector2 delta = pos - joystickCenter;
                        float dist = delta.magnitude;

                        if (dist > joystickRadius)
                            delta = delta.normalized * joystickRadius;

                        float normalizedX = delta.x / joystickRadius;
                        inputX = Mathf.Abs(normalizedX) > deadzone ? normalizedX : 0f;

                        if (joystickThumb != null)
                            joystickThumb.position = joystickCenter + delta;
                    }
                    if (touch.fingerId == jumpTouchId)
                    {
                        jumpActive = true;
                    }
                    break;

                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    if (touch.fingerId == joystickTouchId)
                    {
                        joystickTouchId = -1;
                        inputX = 0;
                        if (joystickBase != null)
                            joystickBase.gameObject.SetActive(false);
                        if (joystickThumb != null && joystickBase != null)
                            joystickThumb.position = joystickBase.position;
                    }
                    if (touch.fingerId == jumpTouchId)
                    {
                        jumpTouchId = -1;
                        if (jumpButtonImage != null)
                        {
                            jumpButtonImage.color = jumpNormalColor;
                            jumpButton.localScale = Vector3.one;
                        }
                    }
                    break;
            }
        }

        // Mouse fallback for editor testing
#if UNITY_EDITOR
        if (Input.GetMouseButton(0))
        {
            Vector2 mousePos = Input.mousePosition;
            if (mousePos.x < Screen.width * 0.5f)
            {
                // Simple left/right based on mouse X relative to center-left
                float centerX = Screen.width * 0.25f;
                inputX = (mousePos.x - centerX) / (Screen.width * 0.15f);
                inputX = Mathf.Clamp(inputX, -1f, 1f);
            }
        }
        else if (joystickTouchId == -1)
        {
            // Don't override keyboard input
        }

        if (Input.GetMouseButtonDown(0) && Input.mousePosition.x >= Screen.width * 0.5f)
        {
            player.SetMobileJump();
        }
#endif
    }
}
