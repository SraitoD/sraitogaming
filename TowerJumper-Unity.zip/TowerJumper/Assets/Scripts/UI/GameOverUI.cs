using UnityEngine;
using UnityEngine.UI;

public class GameOverUI : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject gameOverPanel;
    public Text gameOverTitle;
    public Text scoreText;
    public Text floorText;
    public Text newBestText;
    public Text bestScoreText;
    public Text leaderboardText;
    public Button retryButton;
    public Button menuButton;

    void Start()
    {
        if (gameOverPanel != null)
            gameOverPanel.SetActive(false);

        if (GameManager.Instance != null)
            GameManager.Instance.OnGameOver += ShowGameOver;

        if (retryButton != null)
            retryButton.onClick.AddListener(OnRetry);
        if (menuButton != null)
            menuButton.onClick.AddListener(OnMenu);
    }

    void OnDestroy()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.OnGameOver -= ShowGameOver;
    }

    void ShowGameOver()
    {
        if (gameOverPanel == null) return;
        gameOverPanel.SetActive(true);

        var gm = GameManager.Instance;

        if (gameOverTitle != null)
            gameOverTitle.text = "GAME OVER";

        if (scoreText != null)
            scoreText.text = $"{gm.Score} MÈTRES";

        if (floorText != null)
            floorText.text = $"{gm.FloorCount} FLOORS";

        bool isNewBest = gm.Score >= gm.BestScore;
        if (newBestText != null)
        {
            newBestText.text = isNewBest ? "★ NEW BEST ★" : "";
            newBestText.color = new Color(1f, 0.85f, 0.2f);
        }

        if (bestScoreText != null)
            bestScoreText.text = $"BEST: {gm.BestScore}";

        // Leaderboard
        if (leaderboardText != null)
        {
            var entries = LeaderboardManager.GetTopEntries(10);
            string lb = "TOP SCORES\n";
            string[] medals = { "🥇", "🥈", "🥉" };
            for (int i = 0; i < entries.Count; i++)
            {
                string medal = i < 3 ? medals[i] : $"{i + 1}.";
                lb += $"{medal} {entries[i].score}pts — {entries[i].floors}F — {entries[i].date}\n";
            }
            leaderboardText.text = lb;
        }
    }

    void OnRetry()
    {
        GameManager.Instance?.RetryGame();
    }

    void OnMenu()
    {
        GameManager.Instance?.ReturnToMenu();
    }
}
