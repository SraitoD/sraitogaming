using UnityEngine;
using UnityEngine.UI;

public class HUDController : MonoBehaviour
{
    public static HUDController Instance { get; private set; }

    [Header("Score")]
    public Text scoreText;
    public Text bestText;

    [Header("Combo")]
    public Text comboText;
    public RectTransform comboContainer;

    [Header("Rush Bar")]
    public Image rushBarFill;
    public Image rushBarBg;

    [Header("Biome")]
    public Text biomeText;

    [Header("Floors")]
    public Text floorText;

    [Header("Danger")]
    public Text dangerText;

    [Header("Trick Text")]
    public Text trickText;

    [Header("References")]
    public CameraFollow cameraFollow;

    private float comboPulseTimer;
    private float trickTextTimer;
    private float trickTextDuration = 0.8f;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;

        gm.OnScoreChanged += UpdateScore;
        gm.OnComboChanged += UpdateCombo;
        gm.OnRushChanged += UpdateRush;
        gm.OnFloorChanged += UpdateFloor;

        UpdateScore();
        if (bestText != null)
            bestText.text = $"BEST: {gm.BestScore}";
        if (trickText != null)
            trickText.gameObject.SetActive(false);
    }

    void OnDestroy()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;
        gm.OnScoreChanged -= UpdateScore;
        gm.OnComboChanged -= UpdateCombo;
        gm.OnRushChanged -= UpdateRush;
        gm.OnFloorChanged -= UpdateFloor;
    }

    void Update()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;

        // Combo pulse animation
        if (comboPulseTimer > 0)
        {
            comboPulseTimer -= Time.deltaTime;
            float scale = 1f + 0.3f * (comboPulseTimer / 0.3f);
            if (comboContainer != null)
                comboContainer.localScale = Vector3.one * scale;
        }

        // Rush bar fill
        if (rushBarFill != null)
        {
            if (gm.RushActive)
            {
                rushBarFill.fillAmount = gm.RushTimeLeft / gm.config.RushDuration;
                rushBarFill.color = Color.Lerp(Color.yellow, new Color(1f, 0.8f, 0f), Mathf.Sin(Time.time * 8f) * 0.5f + 0.5f);
            }
            else
            {
                rushBarFill.fillAmount = gm.RushMeter;
                rushBarFill.color = new Color(0.2f, 0.6f, 1f);
            }
        }

        // Danger indicator
        if (dangerText != null && cameraFollow != null)
        {
            switch (cameraFollow.DangerLevel)
            {
                case 0:
                    dangerText.text = "";
                    break;
                case 1:
                    dangerText.text = "↑ RISING";
                    dangerText.color = Color.yellow;
                    break;
                case 2:
                    dangerText.text = "↑ FASTER";
                    dangerText.color = new Color(1f, 0.5f, 0f);
                    break;
                case 3:
                    dangerText.text = "⚠ DANGER ⚠";
                    dangerText.color = Color.red;
                    float blink = Mathf.Sin(Time.time * 10f) > 0 ? 1 : 0;
                    dangerText.color = new Color(1, blink * 0.3f, blink * 0.3f);
                    break;
            }
        }

        // Trick text fade
        if (trickText != null && trickText.gameObject.activeSelf)
        {
            trickTextTimer -= Time.deltaTime;
            if (trickTextTimer <= 0)
            {
                trickText.gameObject.SetActive(false);
            }
            else
            {
                float alpha = trickTextTimer / trickTextDuration;
                trickText.color = new Color(1f, 0.85f, 0.2f, alpha);
                trickText.transform.localScale = Vector3.one * (1f + (1f - alpha) * 0.5f);
            }
        }
    }

    void UpdateScore()
    {
        if (scoreText != null)
            scoreText.text = GameManager.Instance.Score.ToString();
    }

    void UpdateCombo()
    {
        var gm = GameManager.Instance;
        if (comboText != null)
        {
            if (gm.Combo > 1)
            {
                comboText.text = $"x{gm.Combo} COMBO";
                comboText.color = new Color(1f, 0.85f, 0.2f);
                comboPulseTimer = 0.3f;
            }
            else
            {
                comboText.text = "";
            }
        }
    }

    void UpdateRush(bool active)
    {
        // Visual feedback handled in Update()
    }

    void UpdateFloor(int floor)
    {
        if (floorText != null)
            floorText.text = $"{floor}\nFLOORS";
    }

    public void ShowTrickText(string text)
    {
        if (trickText == null) return;
        trickText.text = text;
        trickText.gameObject.SetActive(true);
        trickTextTimer = trickTextDuration;
    }
}
